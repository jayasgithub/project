package controller;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Registration;
@WebServlet(name = "search", urlPatterns = {"/search"})
public class search extends HttpServlet {
 protected void processRequest(HttpServletRequest request, HttpServletResponse
response)
 throws ServletException, IOException {
 response.setContentType("text/html;charset=UTF-8");
 PrintWriter out = response.getWriter();
 HttpSession session = request.getSession(); // WILL IT TAKES THE SAME SESSION THAT IS IN THE search.jsp or it creates a new Session object?
 Registration u = new Registration(session);
 try {
	 if(session.getAttribute("id") != null && session.getAttribute("id").equals("1")){ // will this session stores the previous values.
	 String id = request.getParameter("id");
	 //request.getRequestDispatcher("search.jsp?id=" + id).forward(request, response);
	response.sendRedirect("search.jsp?id="+id); }
	 } catch (Exception e) {
	 e.printStackTrace();
	 }
	 }
 @Override
 protected void doGet(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
 processRequest(request, response);
 }
 protected void doPost(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
 processRequest(request, response);
 }
 public String getServletInfo() {
 return "Short description";
 }// </editor-fold>
}
